package ar.org.centro8.especialidades.web.intefaces.enums;

public enum Dia {
    LUNES,MARTES,MIERCOLES,JUEVES,VIERNES
}
