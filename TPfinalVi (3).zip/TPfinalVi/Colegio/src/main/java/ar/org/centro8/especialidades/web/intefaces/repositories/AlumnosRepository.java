package ar.org.centro8.especialidades.web.intefaces.repositories;

import org.springframework.data.repository.CrudRepository;

import ar.org.centro8.especialidades.web.intefaces.entities.Alumno;

public interface AlumnosRepository extends CrudRepository<Alumno,Integer> {
    
}
